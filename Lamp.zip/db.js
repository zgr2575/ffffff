const Keyv = require('keyv');
const keyv = new Keyv('sqlite://./db.sqlite');

exports.set = async (variable, value) => {
  try {
   keyv.set(variable, value);
  } catch (err) {
    console.error(err);
  }
  return;
}

exports.get = async (variable) => {
  let value;
  try {
    value = keyv.get(variable);
  } catch (err) {
    console.error(err);
  }
  return value;
}

exports.delete = async (variable) => {
  try {
    keyv.delete(variable);
  } catch (err) {
    console.error(err);
  }
  return;
}

exports.clear = async () => {
  try {
    keyv.clear();
  } catch (err) {
    console.error(err);
  }
  return;
}