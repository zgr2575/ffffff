exports.run = async (client, message, args) => {
  message.channel.send({
    embed: {
      color: `RANDOM`,
      description: `Bot Ping: \`${client.ws.ping}ms.\``,
      title: `🏓 Pong!`
    }
  })
}