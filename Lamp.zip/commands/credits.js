exports.run = async (client, message, args) => {
  message.channel.send({
    embed: {
      color: "RANDOM",
      title: 'Credits',
      fields: [
         {
           name: 'Head Developers',
           value: "Coop#3058 \n /-zgr2575-\#0784",
         },
         {
           name: 'Developers',
           value: 'nathann#1048 \n ShadowX#3213'
         }
      ]
    }
  })
}
//  DO NOT CHANGE THIS