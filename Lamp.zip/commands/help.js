exports.run = async (client, message, args) => {
  message.channel.send({
    embed: {
      color: `RANDOM`,
      title: `Commands`,
      description:
        `**• Information**\n` +
        `\`help\` - \`ping\` - \`credits\`\n` +
        `**• Config**\n` +
        `\`connect\` - \`login\` \n` +
        `**• Fun**\n` +
        `\`tts\`\n` +
        `**• Roblox**\n` +
        `\`shout\``
    }
  });
};
exports.run = async (client, message, args) => {
  const m = await message.channel.send({
    embed: {
      color: `RANDOM`,
      description: "<a:loading:739710953301606481> Loading"
    }
  });

  m.edit({
    embed: {
      description:
        `**• Information**\n` +
        `\`help\` - \`ping\` - \`credits\`\n` +
        `**• Config**\n` +
        `\`connect\` - \`login\` \n` +
        `**• Fun**\n` +
        `\`tts\`\n` +
        `**• Roblox**\n` +
        `\`shout\``,
      color: `RANDOM`
    }
  });
  message.react(":loading:739710953301606481");
};
