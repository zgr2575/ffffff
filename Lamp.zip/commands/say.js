exports.run = async (client, message, args) => {
  if(!message.member.permissions.has('MANAGE_MESSAGES')) return message.channel.send('<:no:739672056861294662> You do not have permission to do this!')
  message.delete();
  let msg = args.join(" ")
  if (!args[0]) {
    return message.channel.send({
      embed: {
        color: `RED`,
        description: `<:no:739672056861294662> Error! You must input a message in order for this to work!`
      }
    })
  }
  message.channel.send(msg)
}