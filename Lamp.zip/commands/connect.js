const db = require('../db.js');
const { MessageEmbed } = require('discord.js');
exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("ADMINISTRATOR"))
  return message.channel.send({
    embed: {
      color: "RED",
      description: `<:no:739672056861294662> Error! You don't have permission to use the command!`
    }
    
    
  })
	if (!args[0]) {
		return message.channel.send(`<:no:739672056861294662> Error! Please input your group ID!`);
	}
	const groupId = args[0];
	await db.set(`${message.guild.id}_groupid`, groupId);
	message.channel.send({
    embed: {
      color: 'GREEN',
      title: "Group connected!",
      description: `<:yes:739672095507742891> Your group has been connected to ${
				message.guild.name
			}!`
    }
  })
};
module.exports.aliases = ['connectgroup', 'setgroup', 'group'];
