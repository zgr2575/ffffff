const db = require('../db.js')
const nbx = require('noblox.js')
exports.run = async (client, message, args) => {
if(!message.member.roles.cache.find(role => role.name == "Ranker")) return message.channel.send("<:no:739672056861294662> You must have the Ranker role to use this command!")
const groupid = await db.get(`${message.guild.id}_groupid`)

let msg;
try {
  msg = await nbx.shout(Number(groupid), msg);
} catch (err) {
  return message.channel.send(err)
}
message.channel.send({
  embed: {
    title: "<:yes:739672095507742891> Group Shout posted!",
    description: args.join(" ")
  }
})
}