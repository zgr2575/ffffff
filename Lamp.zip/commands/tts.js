exports.run = async (client, message, args) => {
  if(!message.member.permissions.has('MANAGE_MESSAGES')) return message.channel.send('<:no:739672056861294662> You do not have permission to do this!')
  message.channel.send(args.join(" "), {
    tts: true
  })
}