 const nbx = require('noblox.js')
const db = require('../db.js')
exports.run = async (client, message, args) => {
  if(!message.member.permissions.has('ADMINISTRATOR')) return message.channel.send('<:no:739672056861294662> You do not have permission to do this!') 
  if(!cookie.includes('_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_')) return message.channel.send('<:no:739672056861294662> Invalid cookie! Please include the full cookie, even the warning.')
  const cookie = args.join(" ")
  await db.set(`${message.guild.id}_cookie`, cookie)
  nbx.setCookie(await db.get(`${message.guild.id}_cookie`))
  message.delete()
  message.channel.send({
    embed: {
      color: 'GREEN',
      title: 'Logged in!',
      description: `<:yes:739672095507742891> You have logged in on guild ${message.guild.name}!`
    }
  })
}