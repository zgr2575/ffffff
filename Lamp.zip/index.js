const Discord = require("discord.js")
const client = new Discord.Client()
const fs = require('fs')
const express = require('express')
const app = express()
const dotenv = require('dotenv')
const port = 3000
const nbx = require('noblox.js')
const db = require('./db.js')

app.get('/', (req, res) => res.send('Bot online!'));

app.listen(port, () => console.log(`Bot is listening at http://localhost:${port}`));

client.on('ready', async () => {
  console.log(`> Users at time of startup: ${client.users.cache.size} \n> Servers at time of startup: ${client.guilds.cache.size} `)
  console.log('Bot online!')
  client.user.setActivity('for .help | V2.2', { type: 'WATCHING' })
})

let commandlist = [];

fs.readdir('./commands/', async (err, files) => {
  if(err){
      return console.error('An error occured when checking the commands folder for commands to load: ' + err);
  }
  files.forEach(async (file) => {
      if(!file.endsWith('.js')) return;
      let commandFile = require(`./commands/${file}`);
      commandlist.push({
        file: commandFile,
        name: file.split('.')[0]
      });
  });
});

client.on('message', async (message) => {
  if(message.author.bot || message.channel.type === 'dm') return;
  if(!message.content.startsWith(process.env.PREFIX)){
    if(!message.content.startsWith(`${client.user.id}>`)){
      return;
    }
  }

  let args = message.content.slice(process.env.PREFIX.length).split(' ');
  let commandName = args[0].toLowerCase();
  args.shift();
  if(!commandName){
    commandName = args[0].toLowerCase();
    args.shift();
  }
  let command = commandlist.findIndex((cmd) => cmd.name === commandName);
  if(command == -1){
    command = commandlist.findIndex((cmd) => cmd.file.aliases.includes(commandName));
    if(command == -1) return;
  }
  commandlist[command].file.run(client, message, args);
});

client.login(process.env.TOKEN);